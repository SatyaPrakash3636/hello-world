
//	simple program to Encrypt and Decrypt the Encrypted password

//	Usage : java EncryptPasswordUtil encrypt/decrypt password


import com.tibco.security.*;


public class EncryptPasswordUtil
{
	public static void main(String strArgs[])
	{
		if(strArgs.length < 2)
		{
		//	System.out.println("Please Enter The Password to Encrypt.");
			System.out.println("Usage : java EncryptPasswordUtil encrypt/decrypt password");
			System.exit(0);
		}

		try
		{
			if(strArgs[0].toUpperCase().equals("ENCRYPT"))
			{

				try
				{

					System.out.println("\nEncrypting The Entered Password....");

				//	call function encrypt to Encrypt the password

					String chPassword = ObfuscationEngine.encrypt(strArgs[1].toCharArray());

					System.out.println("\nEncrypted Password is :" + new String(chPassword));
				}
				catch(AXSecurityException e)
				{
					System.out.println("\nAXSecurityException Occured while Encrypting the Password = " + e);
					System.exit(0);
				}
				catch (Exception e1)
				{
					System.out.println("EXception :" +e1);
					System.exit(0);
				}
			}

			else
			if(strArgs[0].toUpperCase().equals("DECRYPT"))
			{
				System.out.println("\nDecrypting The Entered Password....");

				//	call function decrypt to Decrypt the password

				char chPassword[] = ObfuscationEngine.decrypt(strArgs[1]);

				System.out.println("\nDecrypted Password is : " + new String(chPassword));
			}
			else
			{
				System.out.println("\nPlease Specify The Correct Option. encrypt or decrypt");
				System.out.println("Usage : java EncryptPasswordUtil encrypt/decrypt password");
			}

		}
		catch(AXSecurityException e)
		{
			System.out.println("Exception Occured while Decrypting the Entered Password....");
			System.out.println("Password You Entered is not Encrypted Using Tibco Encryption Algorithm.");
			System.out.println("Please Enter The Correct Encrypted Password.");
			System.out.println("Exception = " + e);
			System.exit(0);
		}
		catch(Exception e)
		{
			System.out.println("Exception : " );
			System.exit(0);
		}
	}
}