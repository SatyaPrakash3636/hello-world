import com.tibco.security.*;

public class DecryptPasswordUtil
{
	public static void main(String strArgs[])
	{
		if(strArgs.length < 1)
		{
			System.out.println("Usage : java DecryptPasswordUtil password");
			System.exit(0);
		}
		try
		{
			char firstChar=strArgs[0].charAt(0);
			char secondChar=strArgs[0].charAt(1);
			if (firstChar=='#'&&secondChar=='!')
			{
				char chPassword[] = ObfuscationEngine.decrypt(strArgs[0]);
				System.out.println(new String(chPassword));
			}
		}
		catch(AXSecurityException e)
		{
			System.out.println("Error: " +e);
		}
	}
}
